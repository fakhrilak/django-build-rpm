def halper():
    print("masuk====================")